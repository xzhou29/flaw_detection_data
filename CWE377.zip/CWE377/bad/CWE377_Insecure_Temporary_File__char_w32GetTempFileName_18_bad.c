


#include "std_testcase.h"

#include <wchar.h>
#ifndef _WIN32
#include <unistd.h>
#endif

#include <windows.h>

#define OPEN _open
#define CLOSE _close
#define O_RDWR _O_RDWR
#define O_CREAT _O_CREAT
#define O_EXCL _O_EXCL
#define S_IREAD _S_IREAD
#define S_IWRITE _S_IWRITE


void CWE377_Insecure_Temporary_File__char_w32GetTempFileName_18_bad()
{
    goto sink;
sink:
    {
        char filename[MAX_PATH] = "";
        int fileDesc;
        
        if (GetTempFileNameA(".", "bad", 0, filename) == 0)
        {
            exit(1);
        }
        printLine(filename);
        
        fileDesc = OPEN(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE);
        if (fileDesc != -1)
        {
            printLine("Temporary file was opened...now closing file");
            CLOSE(fileDesc);
        }
    }
}





#ifdef INCLUDEMAIN

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
    printLine("Calling bad()...");
    CWE377_Insecure_Temporary_File__char_w32GetTempFileName_18_bad();
    printLine("Finished bad()");
    return 0;
}

#endif
